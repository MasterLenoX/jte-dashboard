
$('#summernote').summernote({
        placeholder: '',
        tabsize: 2,
        height: 200
      });

$('#formsummernote').summernote({
    placeholder: '',
    tabsize: 2,
    height: 350
  });